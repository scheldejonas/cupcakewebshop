package com.cupcakes.webshop.web.controller;

/**
 * Created by scheldejonas on 11/09/16.
 */
public class CartController {
}
